#include <iostream>
#include <string>
#include <thread>
#include <chrono>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>
#endif

class SimpleHTTPServer {
private:
    int port;
    int server_fd;
    
public:
    SimpleHTTPServer(int p) : port(p) {}
    
    void start() {
        #ifdef _WIN32
        WSADATA wsaData;
        WSAStartup(MAKEWORD(2,2), &wsaData);
        #endif
        
        server_fd = socket(AF_INET, SOCK_STREAM, 0);
        
        struct sockaddr_in address;
        address.sin_family = AF_INET;
        address.sin_addr.s_addr = INADDR_ANY;
        address.sin_port = htons(port);
        
        bind(server_fd, (struct sockaddr *)&address, sizeof(address));
        listen(server_fd, 3);
        
        std::cout << "C++ HTTP Server running on port " << port << std::endl;
        
        while(true) {
            int client_socket = accept(server_fd, nullptr, nullptr);
            
            std::string response = 
                "HTTP/1.1 200 OK\r\n"
                "Content-Type: text/html\r\n"
                "Content-Length: 42\r\n"
                "\r\n"
                "Hello World from C++ Docker Container!";
            
            send(client_socket, response.c_str(), response.length(), 0);
            
            #ifdef _WIN32
            closesocket(client_socket);
            #else
            close(client_socket);
            #endif
        }
    }
};

int main() {
    SimpleHTTPServer server(8080);
    server.start();
    return 0;
}