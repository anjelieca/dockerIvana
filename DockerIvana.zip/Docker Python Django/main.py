import django
from django.conf import settings
from django.http import HttpResponse
from django.urls import path
from django.core.management import execute_from_command_line

# Konfigurasi dasar Django
settings.configure(
    DEBUG=True,
    SECRET_KEY='secret-key',
    ROOT_URLCONF=__name__,
    ALLOWED_HOSTS=['*'],
    MIDDLEWARE=[],
)

# View sederhana
def home(request):
    return HttpResponse("Hello this is Ivana from Django inside Docker!")

urlpatterns = [
    path('', home),
]

if __name__ == "__main__":
    execute_from_command_line(['manage.py', 'runserver', '0.0.0.0:8082'])
